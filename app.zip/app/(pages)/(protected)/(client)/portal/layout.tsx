import { getCurrentDbUser, getCurrentRole } from '@/lib/clerk/auth';
import { redirect } from 'next/navigation';

import SidebarShell from "@/features/layouts/components/SidebarShell";
import {
    CalendarHeart,
    CreditCard,
    FileText,
    UserCircle,
} from "lucide-react";

const navItems = [
    { href: "/portal", label: "My booking", icon: CalendarHeart },
    { href: "/portal/payments", label: "Payments", icon: CreditCard },
    { href: "/portal/documents", label: "Documents", icon: FileText },
    { href: "/portal/account", label: "Account", icon: UserCircle },
];

/**
 * Guards everything under /portal — confirms the signed-in user's
 * role is CLIENT. Middleware already redirects non-clients before
 * this ever runs; this is a defense-in-depth check for anything that
 * bypasses middleware (e.g. server actions called from elsewhere).
 */
export default async function PortalLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const role = await getCurrentRole();
    const user = await getCurrentDbUser();
    if (role !== 'CLIENT') {
        redirect('/staff');
    }

    return (
        <SidebarShell
            navItems={navItems}
            userName={user?.username ?? ""}
            userRole={role}
            notificationCount={2}
        >
            {children}
        </SidebarShell>
    );
}