import { LogoutButton } from '@/components/logout-button';
import { getCurrentDbUser, getCurrentRole } from '@/lib/clerk/auth';
import { redirect } from 'next/navigation';

/**
 * Guards everything under /staff — confirms the signed-in user's role
 * is one of ADMIN, COORDINATOR, VENDOR. Middleware already redirects
 * CLIENT users away; this is defense-in-depth for the same reason as
 * portal/layout.tsx.
 */
export default async function StaffLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const role = await getCurrentRole();
    const user = await getCurrentDbUser();

    if (!role || role === 'CLIENT') {
        redirect('/portal');
    }

    return (
        <div className="min-h-screen bg-slate-50">
            <header className="border-b bg-slate-900 px-6 py-4">
                <span className="font-semibold text-white">
                    Fab Memories Events — Staff Console
                </span>
                <LogoutButton
                    redirectUrl="/"
                    className="rounded border border-slate-600 px-3 py-1.5 text-sm text-white hover:bg-slate-800"
                />
            </header>
            <main className="p-6">{children}</main>
        </div>
    );
}